import os
import openai
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def get_keywords_from_gpt(query):
    prompt = f"""
    A user asked: "{query}"
    Identify and return a list of shopping-related keywords from this query.
    Respond only with a Python list of keywords like: ["keyword1", "keyword2"]
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You're a helpful assistant for a shopping cart app."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2
        )
        result = response["choices"][0]["message"]["content"]
        keywords = eval(result.strip())
        return keywords
    except Exception as e:
        print("⚠️ GPT error:", e)
        return []
