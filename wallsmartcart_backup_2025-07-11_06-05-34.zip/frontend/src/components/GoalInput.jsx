import React, { useState } from 'react';
import Button from './Button.jsx';
import './GoalInput.css';

const GoalInput = ({ onGoalSubmit, isLoading }) => {
  const [goal, setGoal] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (goal.trim()) {
      onGoalSubmit(goal.trim());
    }
  };

  return (
    <div className="goal-input">
      <h2 className="goal-input__title">What are you looking for today?</h2>
      <p className="goal-input__subtitle">Tell us your shopping goal and budget</p>
      
      <form onSubmit={handleSubmit} className="goal-input__form">
        <div className="goal-input__field">
          <input
            type="text"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="e.g., I want snacks under ₹300"
            className="goal-input__input"
            disabled={isLoading}
          />
          <Button 
            type="submit" 
            disabled={!goal.trim() || isLoading}
            className="goal-input__button"
          >
            {isLoading ? 'Finding Products...' : 'Find Products'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default GoalInput;